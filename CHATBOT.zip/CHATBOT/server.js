const express = require('express');
const { GoogleGenerativeAI } = require("@google/generative-ai");
const app = express();

app.use(express.json());
app.use(express.static('public'));

// Substitua pela sua chave real obtida no Google AI Studio
const genAI = new GoogleGenerativeAI("AIzaSyBX-WtvLHlW931IclC_EzepmyDR9S4-EMY");

app.post('/chat', async (req, res) => {
    const { prompt } = req.body;
    
    try {
        const model = genAI.getGenerativeModel({ 
            model: "gemini-3-flash-preview",
            systemInstruction: {
                parts: [{ text: "Você é um tutor prestativo de tecnologia. Responda sempre em Português do Brasil de forma clara." }]
            }
        });

        const result = await model.generateContent(prompt);
        const responseAI = await result.response;
        
        // Enviando a propriedade "resposta" para o frontend consumir
        res.json({ resposta: responseAI.text() });

    } catch (error) {
        console.error("Erro na API:", error.message);
        res.status(500).json({ error: "Erro interno no servidor" });
    }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));